import React, { useState } from "react";

function App() {
  const [inputValue, setInputValue] = useState("");
  const [todos, setTodos] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // Add or Save Edited Todo
  const handleAddOrEdit = () => {
    if (!inputValue.trim()) return; // prevent empty todo

    if (editIndex !== null) {
      const updatedTodos = [...todos];
      updatedTodos[editIndex] = inputValue;
      setTodos(updatedTodos);
      setEditIndex(null);
    } else {
      setTodos([...todos, inputValue]);
    }

    setInputValue("");
  };

  // Delete Todo
  const handleDelete = (index) => {
    setTodos(todos.filter((_, i) => i !== index));
  };

  // Edit Todo
  const handleEdit = (index) => {
    setInputValue(todos[index]);
    setEditIndex(index);
  };

  return (
    <main className="min-h-screen w-full bg-slate-900 flex flex-col items-center gap-10 p-10 text-white">
      <h1 className="text-4xl font-bold text-sky-400">My Todo App</h1>

      {/* Input & Button */}
      <div className="flex items-center gap-4 w-full max-w-xl">
        <input
          type="text"
          placeholder="Enter a task..."
          className="flex-1 px-4 py-2 rounded-lg bg-slate-800 border border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-400"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <button
          onClick={handleAddOrEdit}
          className="px-6 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 transition"
        >
          {editIndex !== null ? "Save" : "Add"}
        </button>
      </div>

      {/* Todo List */}
      <div className="w-full max-w-xl space-y-3">
        {todos.length === 0 && (
          <p className="text-gray-400 text-center">No tasks yet</p>
        )}
        {todos.map((todo, index) => (
          <div
            key={index}
            className="flex justify-between items-center bg-slate-800 px-4 py-2 rounded-lg border border-sky-500"
          >
            <span className="text-lg">{todo}</span>
            <div className="flex gap-2">
              <button
                onClick={() => handleEdit(index)}
                className="px-3 py-1 bg-yellow-500 hover:bg-yellow-400 rounded-lg text-sm transition"
              >
                Edit
              </button>
              <button
                onClick={() => handleDelete(index)}
                className="px-3 py-1 bg-red-500 hover:bg-red-400 rounded-lg text-sm transition"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}

export default App;
